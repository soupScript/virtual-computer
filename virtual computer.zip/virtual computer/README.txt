this is a vm that you can edit to add an os to it!
The os's graphics must you python turtle module
The main editor is filesum but feel free to edit other stuff (not like I can sue you)

-soupScript