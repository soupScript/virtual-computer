from Cpu import *
from gpu import *
import turtle
import os

#scrn is the turtle screen
#there is a turtle called drawer for drawing for the os