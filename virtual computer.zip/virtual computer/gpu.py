import turtle

scrn = turtle.Screen()
scrn.title("")
drawer = turtle.Turtle()




turtle.exitonclick()